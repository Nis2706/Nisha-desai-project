const express = require('express');
const path = require('path');
const session = require('express-session');
const mongoose = require('mongoose');
const fileupload = require('express-fileupload');

const app = express();
const { check, validationResult } = require('express-validator');
const { title } = require('process');
app.use(express.urlencoded({ extended: false }));
app.use(fileupload());

app.use(session({
    secret: 'secret',
    resave: false,
    saveUninitialized: true
}));

mongoose.connect('mongodb://127.0.0.1:27017/admin');

const Login = mongoose.model('login', {
    uname: String,
    pass: String
});
const Page = mongoose.model('page', {
    title: String,
    slug: String,
    image: String,
    content: String
});

app.set('views', path.join(__dirname, 'views'));
app.use(express.static(__dirname + '/public'));
app.set('view engine', 'ejs');

app.use((req, res, next) => {
    Page.find({}).then(pages => {
        res.locals.pages = pages;
        next();
    }).catch(err => {
        console.log('Error loading pages:', err);
        res.locals.pages = [];
        next();
    });
});

app.get('/', (req, res) => {
    res.render('home');
});

app.get('/home', (req, res) => {
    res.render('home');
});

app.get('/login', (req, res) => {
    if (req.session.logIn) {
        Page.find({}).then((data) => {
            res.render('dashboard', { data: data, loggedIn: true, user: req.session.user, message: req.params.qobj });
        }).catch((err) => {
            console.log(err);
        });
    } else {
        res.render('login', { errors: [], logerror: null });
    }
});

app.post('/login', [
    check('user', 'Username Empty').notEmpty(),
    check('pass', 'Password Empty').notEmpty(),
], (req, res) => {
    var errors = validationResult(req);
    if (!errors.isEmpty()) {
        res.render('login', { errors: errors.array() });
    } else {
        Login.findOne({ uname: req.body.user }).then((data) => {
            if (data != null && data.pass == req.body.pass) {
                req.session.logIn = true;
                req.session.user = data.uname;
                res.redirect('/login'); // Redirect to home after successful login
            } else {
                res.render('login', { logerror: "Incorrect Username or Password" });
            }
        }).catch((err) => {
            console.log(err);
        });
    }
});



app.post('/addpage', [
    check('title', 'title can not be Empty').notEmpty(),
    check('slug', 'slug can not be Empty').notEmpty(),
    check('content', 'content can not be Empty').notEmpty(),
], (req, res) => {

    if (req.session.logIn) {

        var errors = validationResult(req);
        if (!errors.isEmpty()) {
            res.render('addpage', { errors: errors.array(), loggedIn: true, user: req.session.user });
        } else {

            var imName = req.files.image.name;
            var im = req.files.image;
            let path = 'public/uploads/' + imName;

            im.mv(path).then(() => {
                console.log("Upload Succesfull");
            }).catch((err) => {
                console.log(err);
            });

            var newPage = new Page({
                title: req.body.title,
                slug: req.body.slug,
                image: '/uploads/' + imName,
                content: req.body.content
            });

            newPage.save().then((data) => {
                res.redirect('/message?msg=Page successfully Added.');


            }).catch((err) => {
                console.log(err);
            });
        }
    }
});

// GET route to render the 'Add Page' form
app.get('/addpage', (req, res) => {

    if (req.session.logIn) {
        res.render('addpage', { loggedIn: true, user: req.session.user });
    }
});


app.get('/editpages', [
    check('title', 'title can not be Empty').notEmpty(),
    check('slug', 'slug can not be Empty').notEmpty(),
    check('content', 'content can not be Empty').notEmpty()], (req, res) => {
    if (req.session.logIn) {
        // I Have Fetch all pages from the database
        Page.find({}).then((data) => {
            res.render('editpages', { data: data, loggedIn: true, user: req.session.user });
        }).catch((err) => {
            console.log(err);
        });
    } else {
        res.redirect('/');
    }
});


// Route to edit a page
app.post('/editpage/:id', [
    check('title', 'Title cannot be empty').notEmpty(),
    check('slug', 'Slug cannot be empty').notEmpty(),
    check('content', 'Content cannot be empty').notEmpty()
], (req, res) => {
    
    if (req.session.logIn) {
        const errors = validationResult(req);
        
        if (!errors.isEmpty()) {
            // Return back to form with previous data and errors
            Page.findById(req.params.id).then((page) => {
                res.render('editpages', {
                    page: page,
                    errors: errors.array(),
                    loggedIn: true,
                    user: req.session.user
                });
            }).catch((err) => console.log(err));
        } else {
            let storePath;

            if (req.files && req.files.image) {
                const im = req.files.image;
                const imName = im.name;
                const uploadPath = 'public/uploads/' + imName;
                storePath = '/uploads/' + imName;

                im.mv(uploadPath).then(() => {
                    console.log("New Image Upload Successful");
                }).catch((err) => {
                    console.log("Image Upload Error: ", err);
                });
            }

            // Find and update the page
            Page.findById(req.params.id).then((page) => {
                if (!page) return res.redirect('/editpages');

                page.title = req.body.title;
                page.slug = req.body.slug;
                page.content = req.body.content;

                if (storePath) {
                    page.image = storePath;
                }

                page.save().then((updatedPage) => {
                    res.redirect('/message?msg=Page Successfully Edited');
                }).catch((err) => console.log("Save Error: ", err));
            }).catch((err) => console.log("Find Error: ", err));
        }
    } else {
        res.redirect('/login');
    }
});
// Route to delete a page
app.get('/deletepage/:id', (req, res) => {
    if (req.session.logIn) {
        Page.findByIdAndDelete(req.params.id).then(() => {
            res.redirect('/message?msg=Page Sucessfully Deleted');
        }).catch((err) => {
            console.log(err);
        });
    } else {
        res.redirect('/');
    }
});


app.get('/editpage/:id', (req, res) => {
    if (req.session.logIn) {
        Page.findById(req.params.id).then((page) => {
            if (!page) return res.redirect('/editpages');

            res.render('editpage', {
                page: page,
                loggedIn: true,
                user: req.session.user,
                errors: []
            });
        }).catch((err) => {
            console.log("Error loading edit page: ", err);
            res.redirect('/editpages');
        });
    } else {
        res.redirect('/login');
    }
});


app.get('/logout', (req, res) => {
    req.session.destroy()
        res.redirect('/message?msg=You have been successfully logged out');
    });




app.get('/message', (req, res) => {
    if (req.session.logIn) {
        const message = req.query.msg;
        res.render('message', { message: message, loggedIn: true, user: req.session.user });
    } else {
        const message = req.query.msg;
        res.render('message', { message: message, loggedIn: false, user:false });
    }
});


app.get('/:slug', (req, res) => {
    Page.findOne({ slug: req.params.slug }).then(page => {
        if (page) {
            res.render('page', {
                title: page.title,
                slug: page.slug,
                imPath: page.image, 
                content: page.content,
                loggedIn: req.session.logIn,
                user: req.session.user,
                page: page
            });
        } else {
            res.status(404).render('page', { page: null }); 
        }

    }).catch(err => {
        console.error(err);
        res.status(500).send('Internal Server Error');
    });
});

app.get('/setup',(req, res)=>{
    
    let loginData = [{
        'uname': 'user',
        'pass': 'user'
    }];
        
    loginData.collection.insertMany(loginData);
    res.send('Database setup complete. You can now proceed with your Exam Review.');
    
});

app.listen(7070);
console.log('Server started at http://localhost:7070');
